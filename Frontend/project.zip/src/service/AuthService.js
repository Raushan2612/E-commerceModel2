import axios from "axios";

class AuthService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/auth`;

  static registerUser = async (registration) => {
    const response = await axios.post(
      `${this.BASE_URL}/register`,
      registration
    );

    return response.data;
  };

  static loginUser = async (loginDetails) => {
    const response = await axios.post(`${this.BASE_URL}/login`, loginDetails);
    return response.data;
  };
}

export default AuthService;
