import axios from "axios";
import axiosInstance from "./utils/Interceptor";

class CategoryService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/category`;

  static createCategory = async (body) => {
    const response = await axiosInstance.post(`${this.BASE_URL}/create`, body);
    return response.data;
  };

  static getAllCategory = async () => {
    const response = await axios.get(`${this.BASE_URL}/get-all`);
    return response.data;
  };

  static getCategoryById = async (categoryId) => {
    const response = await axios.get(
      `${this.BASE_URL}/get-category-by-id/${categoryId}`
    );
    return response.data;
  };

  static updateCategory = async (categoryId, body) => {
    const response = await axiosInstance.put(
      `${this.BASE_URL}/update/${categoryId}`,
      body
    );
    return response.data;
  };

  static deleteCategory = async (categoryId) => {
    const response = await axiosInstance.delete(
      `${this.BASE_URL}/delete/${categoryId}`
    );
    return response.data;
  };
}

export default CategoryService;
