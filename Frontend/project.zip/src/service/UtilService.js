class UtilService {
  static getHeader = () => {
    const token = sessionStorage.getItem("token");
    return {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
  };

  static logout() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("role");
  }

  static isAuthenticated() {
    const token = sessionStorage.getItem("token");
    return !!token;
  }

  static isAdmin() {
    const role = sessionStorage.getItem("role");
    return role === "ROLE_ADMIN";
  }
}

export default UtilService;
