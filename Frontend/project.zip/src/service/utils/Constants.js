import FruitsVegatables from "./../../assets/category/fruits&vegatables.png";
import Dairy from "./../../assets/category/dairy.png";
import Beverages from "./../../assets/category/beverages.png";
import Snacks from "./../../assets/category/snacks.png";
import SkinCare from "./../../assets/category/skincare.png";
import CleaningEssentials from "./../../assets/category/cleaningessentials.png";
import Lays from "./../../assets/brandLogos/lays.png";
import Britannia from "./../../assets/brandLogos/britannia.png";
import Sprite from "./../../assets/brandLogos/sprite.png";
import Cadbury from "./../../assets/brandLogos/cadbury.png";
import Amul from "./../../assets/brandLogos/amul.png";
import ourMisson from "../../assets/ourmission.png";
import ourStory from "../../assets/ourstory.png";
import {
  FaLeaf,
  FaTruck,
  FaHandsHelping,
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaLinkedin,
  FaYoutube,
  FaHome,
  FaShoppingBag,
  FaInfoCircle,
  FaShoppingCart,
} from "react-icons/fa";

export const orderStatus = {
  PENDING: "PENDING",
  CONFIRMED: "CONFIRMED",
  SHIPPED: "SHIPPED",
  DELIVERED: "DELIVERED",
  CANCELLED: "CANCELLED",
  RETURNED: "RETURNED",
};

export const cartTypes = {
  ADD: "ADD_ITEM",
  REMOVE: "REMOVE_ITEM",
  INCREMENT: "INCREMENT_ITEM",
  DECREMENT: "DECREMENT_ITEM",
  CLEAR: "CLEAR_CART",
};

export const featuredCategories = [
  {
    id: 1,
    name: "Fruits & Vegetabl..",
    description:
      "Fresh and organic fruits and vegetables for your daily needs.",
    imageUrl: FruitsVegatables,
  },
  {
    id: 2,
    name: "Dairy & Eggs",
    description: "High-quality dairy products like milk,curd and fresh eggs.",
    imageUrl: Dairy,
  },
  {
    id: 3,
    name: "Snacks",
    description: "Delicious bakery items and snacks to satisfy your cravings.",
    imageUrl: Snacks,
  },
  {
    id: 4,
    name: "Beverages",
    description: "A wide range of beverages to keep you refreshed.",
    imageUrl: Beverages,
  },
  {
    id: 5,
    name: "Skin Care",
    description: "Take care of your skin with our easy-to-use products.",
    imageUrl: SkinCare,
  },
  {
    id: 6,
    name: "Cleaning Essenti...",
    description: "Clean your home with our safe and strong products.",
    imageUrl: CleaningEssentials,
  },
];

export const logos = [Britannia, Lays, Sprite, Cadbury, Amul];

export const aboutSections = [
  {
    title: "Our Mission",
    content: [
      "At PPStores, we are dedicated to providing the freshest and highest quality groceries to our customers. Our mission is to make healthy eating accessible and convenient for everyone.",
      "We believe in supporting local farmers and sustainable practices. Our products are carefully selected to ensure they meet our high standards of quality and freshness.",
      "Join us on our journey to promote a healthier lifestyle and a more sustainable future.",
    ],
    image: ourMisson,
    alt: "Our Mission",
  },
  {
    title: "Our Values",
    content: [
      "Our values are at the core of everything we do. We are committed to:",
      "",
      "We strive to exceed your expectations and make a positive impact on the community.",
    ],
    video: "https://www.youtube.com/embed/XyWB7miAWK4?si=zukPh4dF4xstB_yT",
  },
  {
    title: "Our Story",
    content: [
      "Founded in 2016, PPStores started with a simple goal: to provide fresh and high-quality groceries to our community. Over the years, we have grown and expanded our offerings, but our commitment to quality and customer satisfaction remains unchanged.",
      "We are proud to work with local farmers and suppliers who share our values and dedication to quality. Together, we strive to bring you the best products and a seamless shopping experience.",
      "Thank you for being a part of our journey. We look forward to serving you for many years to come.",
    ],
    image: ourStory,
    alt: "Our Story",
  },
];

export const aboutFeatures = [
  {
    icon: FaLeaf,
    title: "Sustainability",
    description:
      "We are committed to sustainable practices and reducing our environmental footprint.",
  },
  {
    icon: FaTruck,
    title: "Fast Delivery",
    description:
      "Enjoy fast and reliable delivery services to get your groceries on time.",
  },
  {
    icon: FaHandsHelping,
    title: "Community Support",
    description:
      "We support local communities and farmers to promote a healthy and sustainable lifestyle.",
  },
];

export const socialLinks = [
  {
    href: "https://facebook.com",
    icon: FaFacebook,
  },
  {
    href: "https://twitter.com",
    icon: FaTwitter,
  },
  {
    href: "https://instagram.com",
    icon: FaInstagram,
  },
  {
    href: "https://linkedin.com",
    icon: FaLinkedin,
  },
  {
    href: "https://youtube.com",
    icon: FaYoutube,
  },
];

export const navigations = [
  {
    name: "Home",
    link: "/",
    icon: FaHome,
  },
  {
    name: "Shop",
    link: "/shop",
    icon: FaShoppingBag,
  },
  {
    name: "About",
    link: "/about",
    icon: FaInfoCircle,
  },
  {
    name: "Cart",
    link: "/cart",
    icon: FaShoppingCart,
  },
];
