import axiosInstance from "./utils/Interceptor";

class AddressService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/address`;

  static saveAddress = async (body) => {
    const response = await axiosInstance.post(`${this.BASE_URL}/save`, body);
    return response.data;
  };
}

export default AddressService;
