import axios from "axios";
import UtilService from "./UtilService";
import axiosInstance from "./utils/Interceptor";

class ProductService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/product`;

  static addProduct = async (formData) => {
    const response = await axiosInstance.post(
      `${this.BASE_URL}/create`,
      formData,
      {
        headers: {
          ...UtilService.getHeader(),
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data;
  };

  static updateProduct = async (formData) => {
    const response = await axios.put(`${this.BASE_URL}/update`, formData, {
      headers: {
        ...UtilService.getHeader(),
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  };

  static getAllProducts = async () => {
    const response = await axios.get(`${this.BASE_URL}/get-all`);
    return response.data;
  };

  static searchProducts = async (searchValue) => {
    const response = await axios.get(`${this.BASE_URL}/search`, {
      params: { searchValue },
    });
    return response.data;
  };

  static getAllProductsByCategoryId = async (categoryId) => {
    const response = await axios.get(
      `${this.BASE_URL}/get-by-category-id/${categoryId}`
    );
    return response.data;
  };

  static getProductById = async (productId) => {
    const response = await axios.get(
      `${this.BASE_URL}/get-by-product-id/${productId}`
    );
    return response.data;
  };

  static deleteProduct = async (productId) => {
    const response = await axiosInstance.delete(
      `${this.BASE_URL}/delete/${productId}`
    );
    return response.data;
  };
}

export default ProductService;
