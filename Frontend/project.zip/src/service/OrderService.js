import axios from "axios";
import axiosInstance from "./utils/Interceptor";

class OrderService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/order`;

  static createOrder = async (body) => {
    const response = await axiosInstance.post(`${this.BASE_URL}/create`, body);
    return response.data;
  };

  static updateOrderStatus = async (orderItemId, status) => {
    const response = await axiosInstance.put(
      `${this.BASE_URL}/updateOrderStatus/${orderItemId}`,
      {},
      {
        params: { status },
      }
    );
    return response.data;
  };

  static getAllOrdersByUser = async () => {
    const response = await axiosInstance.get(
      `${this.BASE_URL}/getAllOrdersByUser`
    );
    return response.data;
  };

  static getAllOrders = async () => {
    const response = await axiosInstance.get(`${this.BASE_URL}/getAllOrders`);
    return response.data;
  };

  static getOrderById = async (id) => {
    const response = await axiosInstance.get(
      `${this.BASE_URL}/getOrderById/${id}`
    );
    return response.data;
  };
}

export default OrderService;
