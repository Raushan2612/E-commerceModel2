import axiosInstance from "./utils/Interceptor";

class UserService {
  static BASE_URL = `${import.meta.env.VITE_BASE_URL}/user`;

  static getLoggedInUserInfo = async () => {
    const response = await axiosInstance.get(`${this.BASE_URL}/my-info`);
    return response.data;
  };

  static getAllUsers = async () => {
    const response = await axiosInstance.get(`${this.BASE_URL}/get-all`);
    return response.data;
  };

  static alterRole = async (id, role) => {
    const response = await axiosInstance.put(
      `${this.BASE_URL}/alterRole/${id}`,
      {
        role,
      }
    );
    return response.data;
  };

  static loadUserById = async (id) => {
    const response = await axiosInstance.get(
      `${this.BASE_URL}/loadUserById/${id}`
    );
    return response.data;
  };

  static eraseUser = async (id) => {
    const response = await axiosInstance.delete(
      `${this.BASE_URL}/eraseUser/${id}`
    );
    return response.data;
  };
}

export default UserService;
