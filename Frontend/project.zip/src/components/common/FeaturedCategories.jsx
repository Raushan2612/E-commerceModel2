import { Link } from "react-router-dom";

const FeaturedCategories = ({ categories }) => {
  return (
    <section className="container mx-auto py-10 bg-white px-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">
            Featured Categories
          </h2>
          <p className="text-gray-600">Explore our popular categories!</p>
        </div>
        <Link to="/categories" className="text-customPrimary hover:underline">
          View All Categories
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category) => (
          <div
            key={category.id}
            className="max-w-56 rounded-lg overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300"
          >
            <div className="relative">
              <img
                src={category.imageUrl}
                alt={category.name}
                className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="p-4">
              <h2 className="text-xl font-bold text-gray-800 mt-2">
                {category.name}
              </h2>
              <p className="text-gray-600">{category.description}</p>
              <Link
                to={`/shop`}
                className="mt-4 inline-block bg-customPrimary text-white px-4 py-2 rounded-md transition-colors duration-300"
              >
                Shop Now
              </Link>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FeaturedCategories;
