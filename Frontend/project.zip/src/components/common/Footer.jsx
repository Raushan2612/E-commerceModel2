import { Link } from "react-router-dom";
import { navigations, socialLinks } from "../../service/utils/Constants";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white py-10">
      <div className="container mx-auto px-10">
        <div className="flex flex-wrap justify-center text-center md:text-left">
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h2 className="text-xl font-semibold mb-4">Quick Links</h2>
            <ul className="space-y-2">
              {navigations.map((item) => {
                return (
                  <li key={item.name}>
                    <Link to={item.link} className="hover:text-gray-400">
                      {item.name}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h2 className="text-xl font-semibold mb-4">Contact Us</h2>
            <p>Email: support@ppstores.com</p>
            <p>Phone: +91 9876543210</p>
            <p>Address: Armugam Nagar, Naidupet, Nellore, AP.</p>
          </div>
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h2 className="text-xl font-semibold mb-4">Subscribe</h2>
            <p>Get the latest updates and offers.</p>
            <form className="mt-4">
              <input
                type="email"
                placeholder="Your email"
                className="w-2/3 px-4 py-2 rounded-md text-gray-900"
              />
              <button
                type="submit"
                className="mt-2 w-2/3 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md"
              >
                Subscribe
              </button>
            </form>
          </div>
          <div className="w-full md:w-1/4">
            <h2 className="text-xl font-semibold mb-4">Follow Us</h2>
            <div className="flex justify-center md:justify-start space-x-4">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="text-white hover:text-gray-400"
                >
                  <link.icon size={24} />
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-8 text-center">
          <p>&copy; {currentYear} PPStores. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
