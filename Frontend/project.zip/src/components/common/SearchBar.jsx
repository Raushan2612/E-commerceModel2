import { useEffect, useState } from "react";
import { FaSearch } from "react-icons/fa";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import ProductService from "../../service/ProductService";

const SearchBar = ({ setProducts, setError, setSearchQuery, searchQuery }) => {
  const navigate = useNavigate();
  // const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = async (e) => {
    e.preventDefault();
    if (searchQuery.trim() === "") {
      navigate("/shop");
    } else {
      // navigate(`/shop/?search=${searchQuery}`);
      setSearchParams({ search: searchQuery });
    }
  };

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        let allProducts = [];
        // const queryparams = new URLSearchParams(location.search);
        // const searchItem = queryparams.get("search");
        const searchItem = searchParams.get("search");

        if (searchItem) {
          const response = await ProductService.searchProducts(searchItem);
          allProducts = response.productList || [];
        } else {
          const response = await ProductService.getAllProducts();
          allProducts = response.productList || [];
        }
        setProducts(allProducts);
      } catch (error) {
        setProducts([]);
        setError(
          error.response?.data?.message ||
            error.message ||
            "Unable to fetch products"
        );
      }
    };

    fetchProducts();
  }, [location.search, setProducts, setError]);

  return (
    <div className="flex items-center justify-center p-4">
      <form
        className="flex w-full max-w-md bg-white rounded-full overflow-hidden border-2 border-customPrimary"
        onSubmit={handleSearchSubmit}
      >
        <input
          type="text"
          placeholder="Search products..."
          className="w-full px-4 py-3 border-0 focus:outline-none focus:ring-2 focus:ring-customPrimary"
          value={searchQuery}
          onChange={handleSearchChange}
        />
        <button
          className="px-6 py-3 bg-customPrimary text-white hover:bg-customPrimary-dark transition-colors duration-300"
          type="submit"
        >
          <FaSearch />
        </button>
      </form>
    </div>
  );
};

export default SearchBar;
