import { useState } from "react";
import {
  FaStar,
  FaHeart,
  FaShoppingCart,
  FaPlus,
  FaMinus,
  FaEye,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { cartTypes } from "../../service/utils/Constants";

const Product = ({ product, cartItem, dispatch, cart }) => {
  const [isHeartFilled, setIsHeartFilled] = useState(false);

  const addToCart = (product) => {
    dispatch({ type: cartTypes.ADD, payload: product });
  };

  const incrementItem = (product) => {
    dispatch({ type: cartTypes.INCREMENT, payload: product });
  };

  const decrementItem = (product) => {
    const cartItem = cart.find((item) => item.id === product.id);
    if (cartItem.quantity > 1) {
      dispatch({ type: cartTypes.DECREMENT, payload: product });
    } else {
      dispatch({ type: cartTypes.REMOVE, payload: product });
    }
  };

  const handleHeartClick = () => {
    setIsHeartFilled(!isHeartFilled);
  };

  return (
    <div className="max-w-56 bg-white rounded-lg overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
        />
        <button onClick={handleHeartClick} className="absolute top-2 right-2">
          <FaHeart
            size={24}
            className={
              isHeartFilled
                ? "text-red-500 hover:text-red-700"
                : "text-gray-300"
            }
          />
        </button>
        <Link
          className="absolute top-10 right-2 text-gray-500 hover:text-gray-700"
          to={`../product/${product.id}`}
        >
          <FaEye size={24} />
        </Link>
      </div>
      <div className="p-4">
        <span className="text-sm text-gray-500 bg-gray-200 px-2 py-1 rounded-full">
          {product.category.name}
        </span>
        <h2 className="text-xl font-bold text-gray-800 mt-2">{product.name}</h2>
        <p className="text-gray-600">₹{product.price}</p>
        <div className="flex items-center mt-2">
          {[...Array(5)].map((_, index) => (
            <FaStar
              key={index}
              className={`${index < 4 ? "text-yellow-500" : "text-gray-300"}`}
            />
          ))}
          <span className="ml-2 text-gray-600">(4)</span>
        </div>
        <div className="mt-4">
          {cartItem ? (
            <div className="flex items-center justify-between w-full">
              <button
                onClick={() => decrementItem(product)}
                className="p-3 bg-customPrimary text-white rounded-full flex items-center justify-center"
              >
                <FaMinus />
              </button>
              <span className="flex-1 text-center text-lg font-semibold text-gray-700">
                {cartItem.quantity}
              </span>
              <button
                onClick={() => incrementItem(product)}
                className="p-3 bg-customPrimary text-white rounded-full flex items-center justify-center"
              >
                <FaPlus />
              </button>
            </div>
          ) : (
            <button
              onClick={() => addToCart(product)}
              className="flex items-center justify-center w-full px-4 py-2 bg-customPrimary text-white rounded-md hover:bg-customPrimary-dark transition-colors duration-300"
            >
              <FaShoppingCart className="mr-2" /> Add to Cart
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Product;
