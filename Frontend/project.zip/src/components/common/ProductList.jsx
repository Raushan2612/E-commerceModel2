import { useContext } from "react";
import CartContext from "../context/CartContext";
import Product from "./Product"; // Assuming you have a Product component

const ProductList = ({ category, products }) => {
  const { cart, dispatch } = useContext(CartContext);

  return (
    <div className="w-full p-4">
      <h2 className="text-center text-2xl font-bold mb-4 mx-auto">
        {category}
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mx-auto">
        {products.map((product) => {
          const cartItem = cart.find((item) => item.id === product.id);
          return (
            <Product
              key={product.id}
              product={product}
              cartItem={cartItem}
              cart={cart}
              dispatch={dispatch}
            />
          );
        })}
      </div>
    </div>
  );
};

export default ProductList;
