import { useContext, useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { IoMenu } from "react-icons/io5";
import { FaHeart, FaSignOutAlt } from "react-icons/fa";
import { RxCross2 } from "react-icons/rx";
import { FaShoppingCart } from "react-icons/fa";
import UserService from "../../service/UserService";
import { CgProfile } from "react-icons/cg";
import UtilService from "../../service/UtilService";
import { FaPiedPiperPp } from "react-icons/fa6";
import { RiAdminFill } from "react-icons/ri";
import CartContext from "../context/CartContext";
import { navigations } from "../../service/utils/Constants";
import { toast } from "react-toastify";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  const [error, setError] = useState(null);
  const { cart } = useContext(CartContext);

  const isAdmin = UtilService.isAdmin();
  const isAuthenticated = UtilService.isAuthenticated();

  const handleLogout = () => {
    const confirm = window.confirm("Are you sure you want to logout? ");
    if (confirm) {
      UtilService.logout();
      toast.success("logout successful");
      navigate("/login");
    }
  };

  const fetchUserInfo = async () => {
    try {
      const response = await UserService.getLoggedInUserInfo();
      setUserInfo(response.user);
    } catch (error) {
      setError(
        error.response?.data?.message ||
          error.message ||
          "Unable to fetch user info"
      );
    }
  };

  useEffect(() => {
    fetchUserInfo();
  }, [isAuthenticated]);

  if (error && error.includes("ExpiredJwtException")) {
    UtilService.logout();
    navigate("/login");
    alert(error);
  }

  return (
    <>
      <header className="fixed z-20 w-full flex-none bg-customPrimary text-sm font-semibold text-white">
        <nav className="max-w-container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative flex items-center py-4">
            <Link className="flex items-center space-x-2 text-white" to="/">
              <FaPiedPiperPp size={40} />
              <span className="text-2xl font-bold font-mainLogo">Stores</span>
            </Link>

            <div className="ml-auto hidden lg:flex lg:items-center gap-6">
              {navigations.slice(0, 3).map((item) => {
                return (
                  <NavLink
                    to={item.link}
                    className={({ isActive }) =>
                      `flex items-center gap-1 ${
                        isActive
                          ? "bg-white text-customPrimary px-3 py-2 rounded-lg "
                          : ""
                      }`
                    }
                    key={item.name}
                  >
                    {<item.icon />}
                    {item.name}
                  </NavLink>
                );
              })}
              {isAdmin && (
                <NavLink
                  to="/admin"
                  className={({ isActive }) =>
                    `flex items-center gap-1 ${
                      isActive
                        ? "bg-white text-customPrimary px-3 py-2 rounded-lg"
                        : ""
                    }`
                  }
                >
                  <RiAdminFill />
                  Admin
                </NavLink>
              )}
            </div>
            {/* <button
              type="button"
              className="ml-auto flex items-center justify-center rounded-lg lg:ml-8"
            >
              <span className="sr-only">Search components</span>
              <FaSearch size={20} />
            </button> */}
            <div className="ml-auto flex items-center gap-7">
              {/* <NavLink to="/favorites">
                <span className="sr-only">Favourites Component</span>
                <FaHeart size={20} />
              </NavLink> */}
              <NavLink to="/cart" className={"relative"}>
                <span className="sr-only">Cart components</span>
                <FaShoppingCart size={20} />
                <span className="flex items-center justify-center bg-red-600 text-white absolute -top-2 -right-2 text-[9px] rounded-full w-4 h-4">
                  {cart?.length > 0 ? cart?.length : "0"}
                </span>
              </NavLink>
            </div>
            <button
              type="button"
              className="ml-6 flex items-center justify-center lg:hidden"
              onClick={() => setIsOpen(!isOpen)}
            >
              <span className="sr-only">Open navigation</span>
              <IoMenu size={30} />
            </button>
            {!isAuthenticated && (
              <div className="hidden lg:ml-8 lg:flex lg:items-center lg:border-l lg:border-white/15 lg:pl-8">
                <Link to="/register">Register</Link>
                <Link
                  className="inline-flex justify-center rounded-lg text-sm font-semibold py-2.5 px-4 bg-white text-customPrimary ml-8"
                  to="/login"
                >
                  <span>
                    Login <span>→</span>
                  </span>
                </Link>
              </div>
            )}
            {isAuthenticated && (
              <div className="hidden lg:ml-8 lg:flex lg:items-center lg:border-l lg:border-white/15 lg:pl-8">
                <div className="relative inline-flex">
                  <button
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                    className="btn btn-primary"
                    aria-haspopup="menu"
                    aria-expanded={dropdownOpen}
                  >
                    <CgProfile size={25} />
                    <span
                      className={`icon-[tabler--chevron-down] ${
                        dropdownOpen ? "rotate-180" : ""
                      } size-4`}
                    ></span>
                  </button>
                  {dropdownOpen && (
                    <ul className="dropdown-menu absolute top-7 right-0 mt-2 w-60 bg-gray-200 text-customPrimary shadow-lg rounded-lg">
                      <li className="dropdown-header flex items-center gap-2 p-4 border-b border-gray-200">
                        <div>
                          <h6 className="text-base font-semibold">
                            {userInfo.name}
                          </h6>
                          <small className="text-sm text-gray-500">
                            {userInfo.email}
                          </small>
                        </div>
                      </li>
                      <li onClick={() => setDropdownOpen(!dropdownOpen)}>
                        <Link
                          className="dropdown-item block p-4 m-3 rounded-md hover:bg-gray-100"
                          to="/profile"
                        >
                          My Profile
                        </Link>
                      </li>
                      <li
                        onClick={() => {
                          setDropdownOpen(!dropdownOpen);
                          handleLogout();
                        }}
                      >
                        <Link className="dropdown-item p-4 m-3 rounded-md bg-customPrimary text-white flex items-center gap-2">
                          <FaSignOutAlt />
                          Logout
                        </Link>
                      </li>
                    </ul>
                  )}
                </div>
              </div>
            )}
          </div>
        </nav>
      </header>

      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden lg:hidden transition-all ">
          <div className="absolute inset-0 bg-customPrimary/25 backdrop-blur-xs transition-opacity"></div>
          <div
            className="fixed inset-0 flex items-start justify-end overflow-y-auto"
            onClick={() => setIsOpen(!isOpen)}
          >
            <div className="min-h-full w-52 bg-customPrimary ring-1 shadow-2xl ring-black/10 transition">
              <h2 className="sr-only">Navigation</h2>
              <button
                type="button"
                className="absolute top-6 right-6 flex items-center text-white justify-center"
                onClick={() => setIsOpen(false)}
              >
                <span className="sr-only">Close navigation</span>
                <RxCross2 size={30} />
              </button>
              <nav className="divide-y divide-white/10 text-base text-white">
                <div className="px-8 py-6">
                  <Link
                    className="flex-none items-center text-white text-xl font-bold"
                    to="/"
                  >
                    <span className="h-6 w-auto">
                      <FaPiedPiperPp size={35} />
                    </span>
                  </Link>
                </div>
                <div className="px-8 py-6">
                  <div className="space-y-2">
                    {navigations.slice(0, 3).map((item) => {
                      return (
                        <NavLink
                          key={item.name}
                          className="flex items-center gap-2 w-full py-2 font-semibold"
                          to={item.link}
                        >
                          {<item.icon />}
                          {item.name}
                        </NavLink>
                      );
                    })}
                    {isAdmin && (
                      <NavLink
                        className="flex items-center gap-2 w-full py-2 font-semibold"
                        to="/admin"
                      >
                        <RiAdminFill />
                        Admin
                      </NavLink>
                    )}
                  </div>
                </div>
                {!isAuthenticated && (
                  <div className="px-8 py-6">
                    <div className="space-y-4">
                      <Link
                        className="block w-full py-2 font-semibold"
                        to="/register"
                      >
                        Register
                      </Link>
                      <Link
                        className="inline-flex justify-center rounded-lg text-sm font-semibold py-3 px-4 bg-white text-customPrimary w-full"
                        to="/login"
                      >
                        <span>
                          Login <span>→</span>
                        </span>
                      </Link>
                    </div>
                  </div>
                )}
                {isAuthenticated && (
                  <div className="px-8 py-6">
                    <div className="space-y-4">
                      <div>
                        <h6 className="text-base font-semibold">
                          {userInfo.name}
                        </h6>
                        <small className="text-sm text-white">
                          {userInfo.email}
                        </small>
                      </div>
                      <Link
                        className="block w-full py-2 font-semibold"
                        to="/profile"
                      >
                        Profile
                      </Link>
                      <Link
                        className="flex items-center justify-center gap-3 rounded-lg text-sm font-semibold py-3 px-4 bg-white text-customPrimary w-full"
                        to="/logout"
                        onClick={() => {
                          handleLogout();
                        }}
                      >
                        <FaSignOutAlt />
                        <span>Logout</span>
                      </Link>
                    </div>
                  </div>
                )}
              </nav>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;
