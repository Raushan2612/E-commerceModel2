import { FaShoppingCart } from "react-icons/fa";
import heroImage from "../../assets/packaging.png"; // Replace with the path to your image
import { Link } from "react-router-dom";
import ReactTypingEffect from "react-typing-effect";

const Hero = () => {
  const dynamicTexts = [
    "Buy 1, get 1 free on select items!",
    "Save up to 50% on fresh produce!",
    "Exclusive discounts on pantry staples.",
    "Limited-time offer: 20% off on all dairy products!",
    "Free delivery on orders over $50!",
    "Special deals on snacks and beverages.",
    "Weekly discounts on household essentials.",
  ];

  return (
    <div className="flex flex-col lg:flex-row items-center justify-between p-8">
      <div className="lg:w-1/2 w-full justify-items-center">
        <img
          src={heroImage}
          alt="Packaging of products"
          className="w-2/3 h-auto"
        />
      </div>
      <div className="lg:w-1/2 w-full lg:pl-8 mt-8 lg:mt-0">
        <h1 className="text-4xl font-bold text-customPrimary mb-1">
          Get Fresh Grocery
        </h1>
        <h3 className="text-2xl text-gray-800 mb-4">Enjoy Healthy Life</h3>
        <p className="text-lg text-gray-600 mb-6">
          At PPStores, we offering a diverse selection of fresh groceries. Our
          commitment to quality and value ensures you always get the best for
          your money. Experience a seamless and enjoyable shopping journey with
          us!
        </p>
        <ReactTypingEffect
          text={dynamicTexts}
          speed={100}
          eraseSpeed={50}
          eraseDelay={3000}
          typingDelay={500}
          className="text-lg text-orange-600 font-bold"
        />
        <div className="flex space-x-4 mt-6">
          <Link
            to="/shop"
            className="bg-customPrimary text-white px-4 py-2 rounded-md hover:bg-white hover:text-customPrimary border-customPrimary border-2 flex items-center"
          >
            <FaShoppingCart className="mr-2" /> Shop Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Hero;
