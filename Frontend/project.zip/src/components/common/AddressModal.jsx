import { useEffect } from "react";
import AddressService from "../../service/AddressService";
import { toast } from "react-toastify";
import Modal from "../utils/Modal";

const AddressModal = ({
  isOpen,
  closeModal,
  isEdit,
  fetchUserInfo,
  address,
  setAddress,
}) => {
  useEffect(() => {
    if (isEdit) {
      fetchUserInfo();
    } else {
      setAddress({
        street: "",
        city: "",
        state: "",
        zipCode: "",
        country: "",
      });
    }
  }, [isEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAddress((prevAddress) => ({
      ...prevAddress,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await AddressService.saveAddress(address);
      toast.success("Address saved successfully!");
      fetchUserInfo();
      closeModal();
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Failed to save/update address"
      );
    }
  };

  return (
    <Modal
      title={isEdit ? "Edit Address" : "Add Address"}
      isOpen={isOpen}
      closeModal={closeModal}
    >
      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        <div className="overflow-y-scroll h-56 px-2 custom-scrollbar">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Street:
            </label>
            <input
              type="text"
              name="street"
              value={address?.street}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              City:
            </label>
            <input
              type="text"
              name="city"
              value={address?.city}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              State:
            </label>
            <input
              type="text"
              name="state"
              value={address?.state}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Zip Code:
            </label>
            <input
              type="text"
              name="zipCode"
              value={address?.zipCode}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country:
            </label>
            <input
              type="text"
              name="country"
              value={address?.country}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 mb-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div>
          <button
            type="submit"
            className="w-full px-4 py-2 bg-customPrimary text-white rounded"
          >
            {isEdit ? "Update Address" : "Save Address"}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default AddressModal;
