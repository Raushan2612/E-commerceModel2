import Carousel from "react-multi-carousel";
import { Link } from "react-router-dom";
import "react-multi-carousel/lib/styles.css";
import { IoFastFood } from "react-icons/io5";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 6,
    slidesToSlide: 1,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 4,
    slidesToSlide: 1,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 2,
    slidesToSlide: 1,
  },
};

const BannerCategories = ({ categories }) => {
  return (
    <div className="pt-24 z-5">
      <Carousel
        swipeable={false}
        draggable={false}
        showDots={false}
        responsive={responsive}
        ssr={false}
        infinite={true}
        autoPlay={true}
        autoPlaySpeed={3000}
        keyBoardControl={true}
        transitionDuration={1000}
        removeArrowOnDeviceType={["tablet", "mobile"]}
        itemClass="mr-2"
      >
        {categories.map((item) => (
          <Link
            key={item?.id}
            to={"/shop"}
            className="flex items-center gap-3 p-1 py-2 text-customPrimary border border-customPrimary rounded-full hover:shadow-lg"
          >
            <IoFastFood className="pl-5 " size={40} />
            <p className="text-sm font-semibold">{item?.name}</p>
          </Link>
        ))}
      </Carousel>
    </div>
  );
};

export default BannerCategories;
