import React from "react";

const BrandLogos = ({ logos }) => {
  return (
    <section className="py-10 container mx-auto px-4 text-center">
      <div className="mb-6">
        <h2 className="text-4xl font-bold text-gray-800">Popular Brands</h2>
        <p className="text-gray-600">Trusted by top brands worldwide</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
        {logos.map((logo, index) => (
          <div key={index} className="flex justify-center items-center p-4">
            <img
              src={logo}
              alt={`Brand logo ${index + 1}`}
              className="max-h-16 rounded-lg"
            />
          </div>
        ))}
      </div>
    </section>
  );
};

export default BrandLogos;
