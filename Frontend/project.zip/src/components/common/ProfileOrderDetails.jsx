import { Dialog, DialogPanel, DialogTitle } from "@headlessui/react";
import { FaTimes } from "react-icons/fa";
import Modal from "../utils/Modal";

const ProfileOrderDetail = ({ isOpen, closeModal, order }) => {
  // Order Details,
  return (
    <Modal title={"Order Details"} isOpen={isOpen} closeModal={closeModal}>
      <div className="mt-4">
        <div className="mb-4">
          <p className="text-gray-900 font-semibold">Status: {order.status}</p>
          <div className="flex justify-between items-center">
            <p className="text-gray-900">
              Total Items: {order.orderItemList.length}
            </p>
            <p className="text-gray-900">
              Total Price: ₹{order.totalPrice.toFixed(2)}
            </p>
          </div>
        </div>
        <ul className="space-y-4 max-h-48 pr-2 overflow-y-scroll custom-scrollbar">
          {order.orderItemList.map((item) => (
            <li
              key={item.id}
              className="flex justify-between items-center bg-gray-100 p-4 rounded-lg shadow-sm"
            >
              <div>
                <p className="text-gray-900 font-semibold">
                  {item.product.name}
                </p>
                <p className="text-gray-600">Quantity: {item.quantity}</p>
              </div>
              <p className="text-gray-900">₹{item.price.toFixed(2)}</p>
            </li>
          ))}
        </ul>
      </div>
    </Modal>
  );
};

export default ProfileOrderDetail;
