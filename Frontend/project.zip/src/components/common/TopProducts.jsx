import { Link } from "react-router-dom";
import Product from "./Product"; // Ensure this path is correct based on your project structure

const TopProducts = ({ products, cart, dispatch }) => {
  return (
    <section className="container mx-auto py-10 px-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Top Products</h2>
          <p className="text-gray-600">Check out our top-rated products!</p>
        </div>
        <Link to="/shop" className="text-customPrimary hover:underline">
          View All Products
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.slice(0, 4).map((product) => (
          <Product
            key={product.id}
            product={product}
            cartItem={cart.find((item) => item.id === product.id)}
            dispatch={dispatch}
            cart={cart}
          />
        ))}
      </div>
    </section>
  );
};

export default TopProducts;
