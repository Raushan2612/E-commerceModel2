const SmallBanner = ({ title, description, reverse, image }) => {
  return (
    <div
      className={`flex items-center justify-between h-[25vh] p-6 my-6 from-white via-customPrimary to-customPrimary shadow-lg ${
        reverse ? "flex-row-reverse bg-gradient-to-l" : "bg-gradient-to-r"
      }`}
    >
      <div className="w-1/3 ml-10">
        <img
          src={image}
          alt="Couple Shopping"
          className={` h-auto rounded-lg ${reverse ? "w-52" : "w-64"}`}
        />
      </div>
      <div className={`w-2/3 pr-4 ${reverse ? "text-left" : "text-right"}`}>
        <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-2">
          {title}
        </h2>
        <p className="text-sm md:text-base lg:text-lg text-white mb-4">
          {description}
        </p>
      </div>
    </div>
  );
};

export default SmallBanner;
