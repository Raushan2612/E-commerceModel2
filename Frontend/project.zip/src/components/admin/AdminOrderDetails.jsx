import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import OrderService from "../../service/OrderService";
import { FaBox, FaInfoCircle, FaMapMarkerAlt, FaUser } from "react-icons/fa";
import { toast } from "react-toastify";

const OrderStatus = {
  PENDING: "PENDING",
  CONFIRMED: "CONFIRMED",
  SHIPPED: "SHIPPED",
  DELIVERED: "DELIVERED",
  CANCELLED: "CANCELLED",
  RETURNED: "RETURNED",
};

const AdminOrderDetails = () => {
  const { itemId } = useParams();
  const [order, setOrder] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrderDetails(itemId);
  }, [itemId]);

  const fetchOrderDetails = async (itemId) => {
    try {
      const response = await OrderService.getOrderById(itemId);
      setOrder(response.order);
      setSelectedStatus(response.order.status);
    } catch (error) {
      console.log(error.message || error);
    }
  };

  const handleStatusChange = (newStatus) => {
    setSelectedStatus(newStatus);
  };

  const handleSubmitStatusChange = async () => {
    try {
      await OrderService.updateOrderStatus(order.id, selectedStatus);
      toast.success("Order status was successfully updated");
      navigate("/admin/orders");
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Unable to update order status"
      );
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="bg-white p-6 rounded mt-10 shadow-md w-full max-w-4xl">
        <h2 className="text-2xl font-bold mb-4 text-center">Order Details</h2>
        {order ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="p-4 border rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <FaInfoCircle className="mr-2" /> Order Information
                </h3>
                <p>
                  <strong>Order ID:</strong> {order.id}
                </p>
                <p>
                  <strong>Total Price:</strong> ₹{order.totalPrice.toFixed(2)}
                </p>
                <p>
                  <strong>Date Ordered:</strong>{" "}
                  {new Date(order.createdAt).toLocaleDateString()}
                </p>
              </div>

              <div className="p-4 border rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-2 flex items-center">
                  <FaUser className="mr-2" /> User Information
                </h3>
                <p>
                  <strong>Name:</strong> {order.user.name}
                </p>
                <p>
                  <strong>Email:</strong> {order.user.email}
                </p>
                <p>
                  <strong>Phone:</strong> {order.user.phoneNumber}
                </p>
              </div>
            </div>

            <div className="mb-4 p-4 border rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <FaMapMarkerAlt className="mr-2" /> Delivery Address
              </h3>
              <p>
                {order.user.address?.street}, {order.user.address?.city},{" "}
                {order.user.address?.state}, {order.user.address?.country},{" "}
                {order.user.address?.zipCode}
              </p>
            </div>

            <div className="mb-4 p-4 border rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-2 flex items-center">
                <FaBox className="mr-2" /> Product Information
              </h3>
              {order.orderItemList.map((orderItem) => (
                <div key={orderItem.id} className="mb-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="info">
                      <p>
                        <strong>Order Item ID:</strong> {orderItem.id}
                      </p>
                      <p>
                        <strong>Name:</strong> {orderItem.product?.name}
                      </p>
                      <p>
                        <strong>Description:</strong>{" "}
                        {orderItem.product?.description}
                      </p>
                      <p>
                        <strong>Price:</strong> ₹
                        {orderItem.product?.price.toFixed(2)}
                      </p>
                    </div>
                    <div className="info">
                      <p>
                        <strong>Quantity:</strong> {orderItem.quantity}
                      </p>
                      <p>
                        <strong>Total Price:</strong> ₹
                        {orderItem.price.toFixed(2)}
                      </p>
                      {/* <img
                        src={orderItem.product?.imageUrl}
                        alt={orderItem.product?.name}
                        className="mb-4 max-w-full h-auto rounded-lg shadow-md"
                      /> */}
                    </div>
                  </div>
                  <hr className="border-t border-gray-300" />
                </div>
              ))}
            </div>
            <div className="flex flex-col md:flex-row items-center justify-center gap-4 mt-4">
              <h4 className="text-lg font-semibold flex-1">Change Status</h4>
              <select
                className="w-full md:w-auto px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 flex-grow"
                value={selectedStatus}
                onChange={(e) => handleStatusChange(e.target.value)}
              >
                {Object.entries(OrderStatus).map(([key, value]) => (
                  <option key={key} value={key}>
                    {value}
                  </option>
                ))}
              </select>
              <div className="w-full md:w-auto md:pl-4 flex-1">
                <button
                  className="w-full px-4 py-2 bg-customPrimary text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  onClick={handleSubmitStatusChange}
                >
                  Update Status
                </button>
              </div>
            </div>
          </>
        ) : (
          <p>Loading order details...</p>
        )}
      </div>
    </div>
  );
};

export default AdminOrderDetails;
