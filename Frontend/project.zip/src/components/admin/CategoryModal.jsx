import { useState, useEffect } from "react";
import CategoryService from "../../service/CategoryService";
import { toast } from "react-toastify";
import Modal from "../utils/Modal";

const AddEditCategory = ({
  isOpen,
  closeModal,
  isEdit,
  categoryId,
  fetchCategories,
}) => {
  const [name, setName] = useState("");

  useEffect(() => {
    if (isEdit && categoryId) {
      fetchCategory(categoryId);
    } else {
      setName("");
    }
  }, [isEdit, categoryId]);

  const fetchCategory = async (id) => {
    try {
      const response = await CategoryService.getCategoryById(id);
      setName(response.category.name);
    } catch (error) {
      console.log(
        error.response?.data?.message ||
          error.message ||
          "Failed to get the category"
      );
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let response;
      if (isEdit) {
        response = await CategoryService.updateCategory(categoryId, { name });
      } else {
        response = await CategoryService.createCategory({ name });
      }
      if (response.status === 200) {
        toast.success(response.message);
        closeModal();
        fetchCategories();
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Failed to save the category"
      );
    }
  };

  return (
    <Modal
      title={isEdit ? "Edit Category" : "Add Category"}
      isOpen={isOpen}
      closeModal={closeModal}
    >
      <form onSubmit={handleSubmit} className="mt-4">
        <input
          type="text"
          placeholder="Category Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full px-4 py-2 mb-4 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <button
          type="submit"
          className="w-full px-4 py-2 bg-customPrimary text-white rounded"
        >
          {isEdit ? "Update" : "Add"}
        </button>
      </form>
    </Modal>
  );
};

export default AddEditCategory;
