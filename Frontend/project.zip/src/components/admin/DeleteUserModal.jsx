import Modal from "../utils/Modal";

const DeleteUserModal = ({ isOpen, closeModal, user, deleteUser }) => {
  const handleDelete = () => {
    deleteUser(user.id);
    closeModal();
  };

  return (
    <Modal
      title={`Delete User ${user.name}`}
      isOpen={isOpen}
      closeModal={closeModal}
    >
      <div className="mt-4">
        <p>Are you sure you want to delete this user?</p>
      </div>
      <div className="mt-4 flex justify-end">
        <button
          className="px-4 py-2 bg-red-500 text-white rounded mr-2"
          onClick={handleDelete}
        >
          Delete
        </button>
        <button className="px-4 py-2 bg-gray-300 rounded" onClick={closeModal}>
          Cancel
        </button>
      </div>
    </Modal>
  );
};

export default DeleteUserModal;
