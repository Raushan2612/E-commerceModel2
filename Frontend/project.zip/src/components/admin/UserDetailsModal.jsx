import {
  Dialog,
  DialogPanel,
  DialogTitle,
  Transition,
  TransitionChild,
} from "@headlessui/react";
import { Fragment } from "react";
import Modal from "../utils/Modal";

const UserDetailsModal = ({ isOpen, closeModal, user }) => {
  return (
    <Modal title={"User Details"} isOpen={isOpen} closeModal={closeModal}>
      <div className="mt-4">
        <p>
          <strong>Name:</strong> {user.name}
        </p>
        <p>
          <strong>Email:</strong> {user.email}
        </p>
        <p>
          <strong>Phone:</strong> {user.phoneNumber}
        </p>
        <p>
          <strong>Role:</strong> {user.role == "ROLE_ADMIN" ? "ADMIN" : "USER"}
        </p>
        <p>
          <strong>Address:</strong> {user.address?.street}, {user.address?.city}
          , {user.address?.state}, {user.address?.zipCode},{" "}
          {user.address?.country}
        </p>
      </div>
      <div className="mt-4 flex justify-end">
        <button className="px-4 py-2 bg-gray-300 rounded" onClick={closeModal}>
          Close
        </button>
      </div>
    </Modal>
  );
};

export default UserDetailsModal;
