import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FaFilter } from "react-icons/fa";
import OrderService from "../../service/OrderService";
import { orderStatus } from "../../service/utils/Constants";

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [statusFilter, setStatusFilter] = useState("");
  // const [searchStatus, setSearchStatus] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [orders, statusFilter]);

  const fetchOrders = async () => {
    try {
      const response = await OrderService.getAllOrders();
      setOrders(response.orderList);
      setFilteredOrders(response.orderList);
    } catch (err) {
      console.log(
        err.response?.data?.message || err.message || "Unable to fetch orders"
      );
    }
  };

  const filterOrders = () => {
    let filtered = orders;

    if (statusFilter) {
      filtered = filtered.filter((order) => order.status === statusFilter);
    }

    // if (searchStatus) {
    //   filtered = filtered.filter((order) =>
    //     orderStatus[order.status]
    //       .toLowerCase()
    //       .includes(searchStatus.toLowerCase())
    //   );
    // }

    setFilteredOrders(filtered);
  };

  const handleFilterChange = (e) => {
    setStatusFilter(e.target.value);
  };

  // const handleSearchStatusChange = (e) => {
  //   setSearchStatus(e.target.value);
  // };

  const handleOrderDetails = (id) => {
    navigate(`/admin/order-details/${id}`);
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 p-4">
      <div className="bg-white p-6 rounded shadow-md mt-20 w-full max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold mb-4 text-center">Orders</h2>
        <div className="flex justify-between mb-4">
          <div className="flex items-center space-x-2">
            <FaFilter />
            <label>Filter By Status</label>
            <select
              value={statusFilter}
              onChange={handleFilterChange}
              className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All</option>
              {Object.entries(orderStatus).map(([key, value]) => (
                <option key={key} value={key}>
                  {value}
                </option>
              ))}
            </select>
          </div>
          {/* <div className="flex items-center space-x-2">
            <FaSearch />
            <label>Search By Status</label>
            <input
              value={searchStatus}
              onChange={handleSearchStatusChange}
              className="px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            ></input>
          </div> */}
        </div>
        <table className="w-full mb-4 border-collapse">
          <thead>
            <tr>
              <th className="border-b px-4 py-2 text-center">Order ID</th>
              <th className="border-b px-4 py-2 text-center">Customer</th>
              <th className="border-b px-4 py-2 text-center">Status</th>
              <th className="border-b px-4 py-2 text-center">Price</th>
              <th className="border-b px-4 py-2 text-center">Date Ordered</th>
              <th className="border-b px-4 py-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map((order) => (
              <tr key={order.id}>
                <td className="border-b px-4 py-2 text-center">{order.id}</td>
                <td className="border-b px-4 py-2 text-center">
                  {order.user.name}
                </td>
                <td className="border-b px-4 py-2 text-center">
                  {orderStatus[order.status]}
                </td>
                <td className="border-b px-4 py-2 text-center">
                  ₹{order.totalPrice.toFixed(2)}
                </td>
                <td className="border-b px-4 py-2 text-center">
                  {new Date(order.createdAt).toLocaleDateString()}
                </td>
                <td className="border-b px-4 py-2 text-center">
                  <button
                    onClick={() => handleOrderDetails(order.id)}
                    className="px-4 py-2 bg-blue-500 text-white rounded"
                  >
                    Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminOrders;
