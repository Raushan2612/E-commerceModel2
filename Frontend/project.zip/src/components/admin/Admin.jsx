import { useNavigate } from "react-router-dom";
import { FaList, FaBox, FaShoppingCart, FaUser } from "react-icons/fa";

const Admin = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-3xl font-bold mb-8">Welcome Admin</h1>
      <div className="space-y-4 w-full max-w-52">
        <button
          className="flex items-center w-full px-4 py-2 bg-customPrimary text-white rounded justify-start"
          onClick={() => navigate("/admin/users")}
        >
          <FaUser className="mr-2" /> Manage Users
        </button>
        <button
          className="flex items-center w-full px-4 py-2 bg-customPrimary text-white rounded justify-start"
          onClick={() => navigate("/admin/categories")}
        >
          <FaList className="mr-2" /> Manage Categories
        </button>
        <button
          className="flex items-center w-full px-4 py-2 bg-customPrimary text-white rounded justify-start"
          onClick={() => navigate("/admin/products")}
        >
          <FaBox className="mr-2" /> Manage Products
        </button>
        <button
          className="flex items-center w-full px-4 py-2 bg-customPrimary text-white rounded justify-start"
          onClick={() => navigate("/admin/orders")}
        >
          <FaShoppingCart className="mr-2" /> Manage Orders
        </button>
      </div>
    </div>
  );
};

export default Admin;
