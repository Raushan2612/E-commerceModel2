import { useState, useEffect } from "react";
import { FaEdit, FaPlus, FaTrash } from "react-icons/fa";
import ProductService from "../../service/ProductService";
import ProductModal from "./ProductModal";
import { toast } from "react-toastify";

const AdminProduct = () => {
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await ProductService.getAllProducts();
      setProducts(response.productList || []);
    } catch (error) {
      console.log("Error fetching product list", error);
    }
  };

  const openModal = (edit = false, productId = null) => {
    setIsEdit(edit);
    setSelectedProductId(productId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Are you sure you want to delete this product?"
    );
    if (confirmed) {
      try {
        await ProductService.deleteProduct(id);
        fetchProducts();
        toast.success("product deleted successfully");
      } catch (error) {
        toast.error("Error deleting product");
      }
    }
  };

  return (
    <div className="flex flex-col items-center min-h-screen px-4 pt-24">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Products</h2>
          <button
            onClick={() => openModal(false)}
            className="flex items-center px-4 py-2 bg-customPrimary text-white rounded"
          >
            <FaPlus className="mr-2" /> Add
          </button>
        </div>
        <ul className="overflow-y-scroll custom-scrollbar max-h-80 pr-2">
          {products.map((product) => (
            <li
              key={product.id}
              className="flex justify-between items-center mb-4"
            >
              <span className="block">{product.name}</span>
              <div className="flex space-x-2">
                <button
                  className="px-4 py-2 bg-blue-500 text-white rounded flex items-center"
                  onClick={() => openModal(true, product.id)}
                >
                  <FaEdit />
                </button>
                <button
                  className="px-4 py-2 bg-red-500 text-white rounded flex items-center"
                  onClick={() => handleDelete(product.id)}
                >
                  <FaTrash />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <ProductModal
        isOpen={isModalOpen}
        closeModal={closeModal}
        isEdit={isEdit}
        productId={selectedProductId}
        fetchProducts={fetchProducts}
      />
    </div>
  );
};

export default AdminProduct;
