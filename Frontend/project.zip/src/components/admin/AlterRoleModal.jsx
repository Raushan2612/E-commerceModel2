import { useState } from "react";
import Modal from "../utils/Modal";

const AlterRoleModal = ({ isOpen, closeModal, user, alterRole }) => {
  const [newRole, setNewRole] = useState(user.role);

  const handleSubmit = () => {
    alterRole(user.id, newRole);
    closeModal();
  };

  return (
    <Modal
      title={`Alter Role for ${user.name}`}
      isOpen={isOpen}
      closeModal={closeModal}
    >
      <div className="mt-4">
        <select
          value={newRole}
          onChange={(e) => setNewRole(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="ROLE_USER">User</option>
          <option value="ROLE_ADMIN">Admin</option>
        </select>
      </div>
      <div className="mt-4 flex justify-end">
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded mr-2"
          onClick={handleSubmit}
        >
          Save
        </button>
        <button className="px-4 py-2 bg-gray-300 rounded" onClick={closeModal}>
          Cancel
        </button>
      </div>
    </Modal>
  );
};

export default AlterRoleModal;
