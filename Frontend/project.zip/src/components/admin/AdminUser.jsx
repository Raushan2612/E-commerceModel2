import { useState, useEffect } from "react";
import { FaTrash, FaUserShield, FaUserCircle } from "react-icons/fa";
import UserService from "../../service/UserService";
import AlterRoleModal from "./AlterRoleModal";
import DeleteUserModal from "./DeleteUserModal";
import UserDetailsModal from "./UserDetailsModal";
import { toast } from "react-toastify";

const AdminUser = () => {
  const [users, setUsers] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isAlterRoleModalOpen, setIsAlterRoleModalOpen] = useState(false);
  const [isDeleteUserModalOpen, setIsDeleteUserModalOpen] = useState(false);
  const [isUserDetailsModalOpen, setIsUserDetailsModalOpen] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchUsers();
    fetchLoggedInUser();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await UserService.getAllUsers();
      setUsers(response.userList);
    } catch (err) {
      setError(
        err.response?.data?.message || err.message || "Unable to fetch users"
      );
    }
  };

  const fetchLoggedInUser = async () => {
    try {
      const response = await UserService.getLoggedInUserInfo();
      setLoggedInUser(response.user);
    } catch (err) {
      toast.error(
        err.response?.data?.message ||
          err.message ||
          "Unable to fetch logged-in user info"
      );
    }
  };

  const handleAlterRole = async (id, newRole) => {
    try {
      await UserService.alterRole(id, newRole);
      fetchUsers();
      toast.success("user role updated");
    } catch (err) {
      toast.error(
        err.response?.data?.message || err.message || "Unable to alter role"
      );
    }
  };

  const handleDeleteUser = async (id) => {
    try {
      await UserService.eraseUser(id);
      fetchUsers();
      toast.success("User deleted");
    } catch (err) {
      toast.error(
        err.response?.data?.message || err.message || "Unable to delete user"
      );
    }
  };

  const openAlterRoleModal = (user) => {
    setSelectedUser(user);
    setIsAlterRoleModalOpen(true);
  };

  const openDeleteUserModal = (user) => {
    setSelectedUser(user);
    setIsDeleteUserModalOpen(true);
  };

  const openUserDetailsModal = (user) => {
    setSelectedUser(user);
    setIsUserDetailsModalOpen(true);
  };

  const closeModals = () => {
    setIsAlterRoleModalOpen(false);
    setIsDeleteUserModalOpen(false);
    setIsUserDetailsModalOpen(false);
    setSelectedUser(null);
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 p-4">
      <div className="bg-white p-6 rounded shadow-md mt-20 w-full max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold mb-4 text-center">Users</h2>
        {error && <p className="text-red-500 mb-4 text-center">{error}</p>}
        <table className="w-full mb-4 border-collapse">
          <thead>
            <tr>
              <th className="border-b px-4 py-2 text-center">User ID</th>
              <th className="border-b px-4 py-2 text-center">Name</th>
              <th className="border-b px-4 py-2 text-center">Email</th>
              <th className="border-b px-4 py-2 text-center">Role</th>
              <th className="border-b px-4 py-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users
              .filter((user) => user.id !== loggedInUser?.id)
              .map((user) => (
                <tr key={user.id}>
                  <td className="border-b px-4 py-2 text-center">{user.id}</td>
                  <td className="border-b px-4 py-2 text-center">
                    {user.name}
                  </td>
                  <td className="border-b px-4 py-2 text-center">
                    {user.email}
                  </td>
                  <td className="border-b px-4 py-2 text-center">
                    {user.role === "ROLE_ADMIN" ? "ADMIN" : "USER"}
                  </td>
                  <td className="border-b px-4 py-2 text-center">
                    <button
                      onClick={() => openUserDetailsModal(user)}
                      className="px-4 py-2 bg-blue-500 text-white rounded mr-2"
                    >
                      <FaUserCircle />
                    </button>
                    <button
                      onClick={() => openAlterRoleModal(user)}
                      className="px-4 py-2 bg-yellow-500 text-white rounded mr-2"
                    >
                      <FaUserShield />
                    </button>
                    <button
                      onClick={() => openDeleteUserModal(user)}
                      className="px-4 py-2 bg-red-500 text-white rounded"
                    >
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {selectedUser && (
        <>
          <AlterRoleModal
            isOpen={isAlterRoleModalOpen}
            closeModal={closeModals}
            user={selectedUser}
            alterRole={handleAlterRole}
          />
          <DeleteUserModal
            isOpen={isDeleteUserModalOpen}
            closeModal={closeModals}
            user={selectedUser}
            deleteUser={handleDeleteUser}
          />
          <UserDetailsModal
            isOpen={isUserDetailsModalOpen}
            closeModal={closeModals}
            user={selectedUser}
          />
        </>
      )}
    </div>
  );
};

export default AdminUser;
