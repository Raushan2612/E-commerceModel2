import { useState, useEffect } from "react";
import { FaEdit, FaPlus, FaTrash } from "react-icons/fa";
import CategoryService from "../../service/CategoryService";
import CategoryModal from "./CategoryModal";
import { toast } from "react-toastify";

const AdminCategory = () => {
  const [categories, setCategories] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await CategoryService.getAllCategory();
      setCategories(response.categoryList || []);
    } catch (error) {
      console.log("Error fetching category list", error);
    }
  };

  const openModal = (edit = false, categoryId = null) => {
    setIsEdit(edit);
    setSelectedCategoryId(categoryId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleDelete = async (id) => {
    const confirmed = window.confirm(
      "Are you sure you want to delete this category?"
    );
    if (confirmed) {
      try {
        await CategoryService.deleteCategory(id);
        fetchCategories();
        toast.success("category deleted");
      } catch (error) {
        toast.error("Error deleting category");
      }
    }
  };

  return (
    <div className="flex flex-col items-center min-h-screen px-4 pt-24">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Categories</h2>
          <button
            onClick={() => openModal(false)}
            className="flex items-center px-4 py-2 bg-customPrimary text-white rounded"
          >
            <FaPlus className="mr-2" /> Add
          </button>
        </div>
        <ul className="overflow-y-scroll custom-scrollbar max-h-80 pr-2">
          {categories.map((category) => (
            <li
              key={category.id}
              className="flex justify-between items-center mb-4"
            >
              <span className="block">{category.name}</span>
              <div className="flex space-x-2">
                <button
                  className="px-4 py-2 bg-blue-500 text-white rounded flex items-center"
                  onClick={() => openModal(true, category.id)}
                >
                  <FaEdit />
                </button>
                <button
                  className="px-4 py-2 bg-red-500 text-white rounded flex items-center"
                  onClick={() => handleDelete(category.id)}
                >
                  <FaTrash />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
      <CategoryModal
        isOpen={isModalOpen}
        closeModal={closeModal}
        isEdit={isEdit}
        categoryId={selectedCategoryId}
        fetchCategories={fetchCategories}
      />
    </div>
  );
};

export default AdminCategory;
