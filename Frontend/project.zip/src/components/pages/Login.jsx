import { useState } from "react";
import {
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaShoppingCart,
} from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import AuthService from "../../service/AuthService";
import { toast } from "react-toastify";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleChangeEmail = (e) => {
    setEmail(e.target.value);
  };
  const handleChangePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await AuthService.loginUser({ email, password });
      if (response.status === 200) {
        sessionStorage.setItem("token", response.token);
        sessionStorage.setItem("role", response.role);
        toast.success("User logged in successfully");
        navigate("/");
      }
    } catch (error) {
      toast.error(
        error.response?.data.message ||
          error.message ||
          "unable to login a user"
      );
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen pt-20 bg-gray-200">
      <div className="flex flex-col m-4 md:flex-row bg-gradient-to-b from-customPrimary to-white via-customPrimary via-45% sm:via-40% to-white to-45% sm:to-40% md:bg-gradient-to-r  md:via-50% md:to-50% p-6 rounded-lg shadow-lg w-full max-w-3xl">
        <div className="w-full md:w-1/2 flex flex-col justify-center items-center p-4">
          <FaShoppingCart className="text-5xl text-white mb-3" />
          <h2 className="text-2xl font-bold mb-3 text-white">
            Welcome Back to PPStores!
          </h2>
          <p className="text-white mb-4 text-center">
            We're thrilled to have you back. Log in to access your account and
            continue shopping for the best deals on a wide range of products.
          </p>
        </div>
        {/* <div className="border-t md:border-t-0 md:border-l border-gray-300"></div> */}
        <div className="w-full mt-8 md:mt-0 md:w-1/2 pl-0 pt-2 md:pt-0 md:pl-6">
          <h2 className="text-xl font-bold mb-2 text-center text-customPrimary">
            Continue to Shop
          </h2>
          <p className="text-center text-gray-600 mb-4">
            Enter your email and password to log in and continue enjoying our
            exclusive deals and offers.
          </p>
          <form className="space-y-3" onSubmit={handleSubmit}>
            <div className="relative">
              <FaEnvelope className="absolute left-3 top-3 text-gray-400" />
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={email}
                onChange={handleChangeEmail}
                required
              />
            </div>
            <div className="relative">
              <FaLock className="absolute left-3 top-3 text-gray-400" />
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={password}
                onChange={handleChangePassword}
                required
              />
              <button
                type="button"
                className="absolute right-3 top-3 text-gray-400"
                onClick={togglePasswordVisibility}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-customPrimary text-white rounded-lg"
            >
              Log In
            </button>
          </form>
          <p className="mt-3 text-center text-gray-600">
            Don't have an account?{" "}
            <Link to="/register" className="text-customPrimary hover:underline">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
