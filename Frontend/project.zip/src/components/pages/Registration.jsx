import { useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaPhone,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaShoppingCart,
} from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import AuthService from "../../service/AuthService";
import { toast } from "react-toastify";

const Registration = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phoneNumber: "",
    password: "",
  });

  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await AuthService.registerUser(formData);
      if (response.status === 200) {
        toast.success("User registered successfully");
        navigate("/login");
      }
    } catch (error) {
      toast.error(
        error.response?.data.message ||
          error.message ||
          "unable to register a user"
      );
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen pt-20 bg-gray-200">
      <div className="flex flex-col m-4 md:flex-row bg-gradient-to-b from-customPrimary via-customPrimary to-white via-40% to-40% md:bg-gradient-to-r  md:via-50% md:to-50% p-6 rounded-lg shadow-lg w-full max-w-3xl">
        <div className="w-full md:w-1/2 flex flex-col justify-center items-center p-4">
          <FaShoppingCart className="text-5xl text-white mb-3" />
          <h2 className="text-2xl font-bold mb-3 text-white">
            Welcome to PPStores!
          </h2>
          <p className="text-white mb-4 text-center">
            We're thrilled to have you join our community. At PPStores, you'll
            find the best deals on a wide range of products. Create your account
            now to start shopping and enjoy exclusive member benefits!
          </p>
        </div>
        {/* <div className="border-t md:border-t-0 md:border-l border-gray-300"></div> */}
        <div className="w-full mt-8 md:mt-0 md:w-1/2 pl-0 pt-10 md:pt-0 md:pl-6">
          <h2 className="text-xl font-bold mb-2 text-center text-customPrimary">
            Join PPStores Today
          </h2>
          <p className="text-center text-gray-600 mb-4">
            Fill in the details below to create your account and start your
            shopping journey with us.
          </p>
          <form className="space-y-3" onSubmit={handleSubmit}>
            <div className="relative">
              <FaUser className="absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                name="name"
                placeholder="Name"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="relative">
              <FaEnvelope className="absolute left-3 top-3 text-gray-400" />
              <input
                type="email"
                name="email"
                placeholder="Email"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="relative">
              <FaPhone className="absolute left-3 top-3 text-gray-400" />
              <input
                type="tel"
                name="phoneNumber"
                placeholder="Phone Number"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={formData.phoneNumber}
                onChange={handleChange}
                required
              />
            </div>
            <div className="relative">
              <FaLock className="absolute left-3 top-3 text-gray-400" />
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                className="pl-10 pr-4 py-2 w-full border rounded-lg focus:outline-none focus:border-gray-800"
                value={formData.password}
                onChange={handleChange}
                required
              />
              <button
                type="button"
                className="absolute right-3 top-3 text-gray-400"
                onClick={togglePasswordVisibility}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-customPrimary text-white rounded-lg"
            >
              Register
            </button>
          </form>
          <p className="mt-3 text-center text-gray-600">
            Already have an account?{" "}
            <Link to="/login" className="text-customPrimary hover:underline">
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Registration;
