import { useNavigate } from "react-router-dom";
import CartContext from "../context/CartContext";
import OrderService from "../../service/OrderService";
import { FaMinus, FaPlus, FaTimes } from "react-icons/fa";
import UtilService from "../../service/UtilService";
import UserService from "../../service/UserService";
import { cartTypes } from "../../service/utils/Constants";
import { toast } from "react-toastify";
import { useContext } from "react";

const Cart = () => {
  const { cart, dispatch } = useContext(CartContext);
  const navigate = useNavigate();

  const incrementItem = (product) => {
    dispatch({ type: cartTypes.INCREMENT, payload: product });
  };

  const decrementItem = (product) => {
    const cartItem = cart.find((item) => item.id === product.id);
    if (cartItem && cartItem.quantity > 1) {
      dispatch({ type: cartTypes.DECREMENT, payload: product });
    } else {
      dispatch({ type: cartTypes.REMOVE, payload: product });
    }
  };

  const totalPrice = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  const handleCheckout = async () => {
    if (!UtilService.isAuthenticated()) {
      toast.warn("You need to login first before you can place an order");
      navigate("/login");
      return;
    }

    const response = await UserService.getLoggedInUserInfo();

    if (!response.user.address) {
      toast.warn("You should add address first before placing an order");
      navigate("/profile");
      return;
    }

    const orderItems = cart.map((item) => ({
      productId: item.id,
      quantity: item.quantity,
    }));

    const orderRequest = {
      totalPrice,
      items: orderItems,
    };

    try {
      const response = await OrderService.createOrder(orderRequest);
      toast.success(response.message);

      if (response.status === 200) {
        dispatch({ type: cartTypes.CLEAR });
      }
    } catch (error) {
      toast.error(
        error.response?.data?.message ||
          error.message ||
          "Failed to place an order"
      );
    }
  };

  const removeItem = (product) => {
    dispatch({ type: "REMOVE_ITEM", payload: product });
  };

  return (
    <div className="flex flex-col items-center pt-20">
      {cart.length === 0 ? (
        <div className="flex flex-col h-[85vh] items-center justify-center">
          <p className="text-xl mb-4">Your cart is empty</p>
          <button
            onClick={() => navigate("/shop")}
            className="bg-customPrimary text-white px-6 py-3 rounded-lg"
          >
            Go to Shopping
          </button>
        </div>
      ) : (
        <div className="w-full max-w-4xl flex flex-col md:flex-row">
          <div className="w-full md:w-2/3">
            <ul className="space-y-6">
              {cart.map((item) => (
                <li
                  key={item.id}
                  className="relative flex flex-col sm:flex-row items-center border-b pb-6"
                >
                  <button
                    onClick={() => removeItem(item)}
                    className="absolute top-0 right-0 text-red-500 p-2"
                  >
                    <FaTimes />
                  </button>
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="h-32 w-32 sm:h-48 sm:w-48 rounded-md object-cover object-center border border-gray-300 hover:border-gray-500 duration-300 mb-4 sm:mb-0 sm:mr-6"
                  />
                  <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
                    <h2 className="text-xl font-semibold mb-2">{item.name}</h2>
                    <p className="text-sm mb-4">{item.description}</p>
                    <div className="quantity-controls flex items-center mb-4">
                      <button
                        onClick={() => decrementItem(item)}
                        className="bg-customPrimary text-white p-2 rounded-full mr-2"
                      >
                        <FaMinus />
                      </button>
                      <span className="text-xl">{item.quantity}</span>
                      <button
                        onClick={() => incrementItem(item)}
                        className="bg-customPrimary text-white p-2 rounded-full ml-2"
                      >
                        <FaPlus />
                      </button>
                    </div>
                    <span className="text-xl font-semibold">
                      ₹{item.price.toFixed(2)}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="w-full md:w-1/3 lg:pl-6 mt-6 lg:mt-0">
            <div className="p-4 border rounded-lg sticky top-20">
              <h2 className="text-2xl font-semibold mb-4">Order Summary</h2>
              <p className="text-lg mb-2">
                Total Price: ₹{totalPrice.toFixed(2)}
              </p>
              <p className="text-lg mb-2">
                Tax: ₹{(totalPrice * 0.1).toFixed(2)}
              </p>
              <p className="text-lg mb-2">Other Charges: ₹5.00</p>
              <h3 className="text-xl font-semibold mt-4">
                Grand Total: ₹{(totalPrice + totalPrice * 0.1 + 5).toFixed(2)}
              </h3>
              <button
                className="checkout-button bg-customPrimary text-white px-6 py-3 rounded-lg mt-4 w-full"
                onClick={handleCheckout}
              >
                Checkout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
