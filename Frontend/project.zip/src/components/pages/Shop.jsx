import { useEffect, useState } from "react";
import ProductList from "../common/ProductList";
import SearchBar from "../common/SearchBar";
import ProductService from "../../service/ProductService";
import CategoryService from "../../service/CategoryService";

const Loader = () => (
  <div className="flex justify-center h-screen">
    <div className="w-16 h-16 border-4 border-t-4 border-customPrimary rounded-full animate-spin"></div>
  </div>
);

const Shop = () => {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await CategoryService.getAllCategory();
      const allCategories = [
        { id: "all", name: "All" },
        ...response.categoryList,
      ];
      setCategories(allCategories);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Unable to fetch categories"
      );
    }
  };

  useEffect(() => {
    if (selectedCategory) {
      fetchProducts(selectedCategory);
    }
  }, [selectedCategory]);

  const fetchProducts = async (categoryId) => {
    try {
      setLoading(true);
      setProducts([]);
      setError("");
      let response;
      if (categoryId === "all") {
        response = await ProductService.getAllProducts();
      } else {
        response = await ProductService.getAllProductsByCategoryId(categoryId);
      }
      const allProducts = response.productList || [];
      setProducts(allProducts);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      setProducts([]);
      setError(
        error.response?.data?.message ||
          error.message ||
          "Unable to fetch products"
      );
    }
  };

  const handleCategoryChange = (categoryId) => {
    setSelectedCategory(categoryId);
  };

  return (
    <div className="container mx-auto pt-20 px-4">
      <SearchBar
        setProducts={setProducts}
        setError={setError}
        setSearchQuery={setSearchQuery}
        searchQuery={searchQuery}
      />
      {searchQuery.length === 0 && (
        <div className="mb-4 flex justify-center">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => handleCategoryChange(category.id)}
              className={`px-4 py-2 mr-2 border-2 border-customPrimary rounded-full ${
                selectedCategory === category.id
                  ? "bg-customPrimary text-white"
                  : ""
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      )}
      {loading ? (
        <Loader />
      ) : (
        <ProductList
          category={
            searchQuery.length === 0
              ? categories.find((cat) => cat.id === selectedCategory)?.name
              : `You searched for: ${searchQuery}`
          }
          products={products}
        />
      )}
      {error && (
        <div className="flex justify-center h-64">
          <p className="text-red-500 text-2xl md:text-4xl text-center">
            {error}
          </p>
        </div>
      )}
    </div>
  );
};

export default Shop;
