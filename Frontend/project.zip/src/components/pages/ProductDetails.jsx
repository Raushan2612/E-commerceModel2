import { useContext, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import CartContext from "../context/CartContext";
import { FaPlus, FaMinus, FaStar } from "react-icons/fa";
import ProductService from "../../service/ProductService";
import { cartTypes } from "../../service/utils/Constants";

const ProductDetails = () => {
  const { productId } = useParams();
  const { cart, dispatch } = useContext(CartContext);
  const [productDetails, setProductDetails] = useState(null);

  useEffect(() => {
    fetchProductDetails();
  }, [productId]);

  const fetchProductDetails = async () => {
    try {
      const response = await ProductService.getProductById(productId);
      setProductDetails(response.product);
    } catch (error) {
      console.log(error.message || error);
    }
  };

  const addToCart = () => {
    if (productDetails) {
      dispatch({ type: cartTypes.ADD, payload: productDetails });
    }
  };

  const incrementItem = () => {
    if (productDetails) {
      dispatch({ type: cartTypes.INCREMENT, payload: productDetails });
    }
  };

  const decrementItem = () => {
    if (productDetails) {
      const cartItem = cart.find((item) => item.id === productDetails.id);
      if (cartItem && cartItem.quantity > 1) {
        dispatch({ type: cartTypes.DECREMENT, payload: productDetails });
      } else {
        dispatch({ type: cartTypes.REMOVE, payload: productDetails });
      }
    }
  };

  if (!productDetails) {
    return <p className="text-center text-xl">Loading product details...</p>;
  }

  const cartItem = cart.find((item) => item.id === productDetails.id);

  return (
    <div className="flex flex-col sm:flex-row items-center justify-center py-6 h-screen sm:py-10">
      <Link
        to={`/product/${productDetails.id}`}
        className="mb-6 sm:mb-0 sm:mr-6"
      >
        <img
          src={productDetails.imageUrl}
          alt={productDetails.name}
          className="h-64 w-64 sm:h-80 sm:w-80 rounded-md object-cover object-center border border-gray-300 hover:border-gray-500 duration-300"
        />
      </Link>
      <div className="flex flex-col items-center sm:items-start text-center sm:text-left max-w-lg">
        <h3 className="text-2xl font-semibold mb-2">{productDetails.name}</h3>
        <p className="text-sm mb-4">
          Category:{" "}
          <span className="font-medium">{productDetails.category.name}</span>
        </p>
        <p className="text-sm mb-4">
          Description:{" "}
          <span className="font-medium">{productDetails.description}</span>
        </p>
        <p className="text-xl font-semibold mb-4">
          ₹{productDetails.price.toFixed(2)}
        </p>
        <p className="text-sm mb-4 flex justify-center items-center gap-2">
          <FaStar className="text-yellow-500" /> 4.5 (200 reviews)
        </p>
        <p className="text-sm mb-4">Viewed by 500 members</p>
        <p className="text-sm mb-4">Stock: 20 available</p>
        {cartItem ? (
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={decrementItem}
              className="bg-customPrimary text-white p-3 rounded-full mr-2"
            >
              <FaMinus />
            </button>
            <span className="text-xl">{cartItem.quantity}</span>
            <button
              onClick={incrementItem}
              className="bg-customPrimary text-white p-3 rounded-full ml-2"
            >
              <FaPlus />
            </button>
          </div>
        ) : (
          <button
            onClick={addToCart}
            className="bg-customPrimary text-white p-2 rounded-lg"
            style={{ minWidth: "150px" }}
          >
            Add To Cart
          </button>
        )}
      </div>
    </div>
  );
};

export default ProductDetails;
