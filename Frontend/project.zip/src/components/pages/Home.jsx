import BannerCategories from "../common/BannerCategories";
import Hero from "../common/Hero";
import SmallBanner from "../common/SmallBanner";
import coupleShopping from "../../assets/coupleshopping.png";
import shoppingCart from "../../assets/shoppingcart.png";
import TopProducts from "../common/TopProducts";
import CartContext from "../context/CartContext";
import { useContext, useEffect, useState } from "react";
import ProductService from "../../service/ProductService";
import FeaturedCategories from "../common/FeaturedCategories";
import CategoryService from "../../service/CategoryService";
import BrandLogos from "../common/BrandLogos";
import { featuredCategories, logos } from "../../service/utils/Constants";

const Home = () => {
  const { cart, dispatch } = useContext(CartContext);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(false);

  const fetchProducts = async () => {
    try {
      let allProducts = [];
      const response = await ProductService.getAllProducts();
      allProducts = response.productList || [];
      setProducts(allProducts);
    } catch (error) {
      setError(
        error.response?.data?.message ||
          error.message ||
          "unable to fetch products"
      );
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await CategoryService.getAllCategory();
      setCategories(response.categoryList || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Unable to fetch categories"
      );
    }
  };

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  return (
    <>
      <BannerCategories categories={categories} />

      <Hero />

      <BrandLogos logos={logos} />

      <SmallBanner
        reverse={true}
        title={"Exclusive Deals Just for You!"}
        description={
          "Unbeatable prices on your favorite items. Shop now and save big."
        }
        image={shoppingCart}
      />

      <TopProducts products={products} cart={cart} dispatch={dispatch} />

      <SmallBanner
        reverse={false}
        title={"Enjoy Shopping Together!"}
        description={
          "Discover amazing deals and have fun shopping with your loved ones."
        }
        image={coupleShopping}
      />

      <FeaturedCategories categories={featuredCategories} />
    </>
  );
};

export default Home;
