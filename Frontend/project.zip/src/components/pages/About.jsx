import {
  aboutSections,
  aboutFeatures,
  socialLinks,
} from "../../service/utils/Constants";

const About = () => {
  return (
    <section className="container mx-auto pt-24 pb-16 px-8">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-800">About Us</h1>
        <p className="text-gray-600 mt-4">
          Learn more about our mission, values, and what makes us unique.
        </p>
      </div>

      {aboutSections.map((section, index) => (
        <div
          key={index}
          className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-10"
        >
          {section.video ? (
            <>
              <div className="flex justify-center items-center">
                <iframe
                  width="560"
                  height="315"
                  src={section.video}
                  title="YouTube video player"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allowFullScreen
                ></iframe>
              </div>
              <div>
                <h2 className="text-3xl font-bold text-gray-800 mb-4">
                  {section.title}
                </h2>
                {section.content.map((paragraph, idx) => (
                  <p key={idx} className="text-gray-600 mb-4">
                    {idx == 1 ? (
                      <ul className="list-decimal list-inside text-gray-600 mb-4">
                        <li>
                          Quality: Providing the best products to our customers.
                        </li>
                        <li>
                          Sustainability: Supporting eco-friendly practices.
                        </li>
                        <li>
                          Community: Building strong relationships with local
                          farmers and suppliers.
                        </li>
                        <li>
                          Customer Service: Ensuring a seamless shopping
                          experience.
                        </li>
                      </ul>
                    ) : (
                      paragraph
                    )}
                  </p>
                ))}
              </div>
            </>
          ) : (
            <>
              <div>
                <h2 className="text-3xl font-bold text-gray-800 mb-4">
                  {section.title}
                </h2>
                {section.content.map((paragraph, idx) => (
                  <p key={idx} className="text-gray-600 mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>
              <div className="flex justify-center items-center">
                <img
                  src={section.image}
                  alt={section.alt}
                  className="rounded-lg w-9/12"
                />
              </div>
            </>
          )}
        </div>
      ))}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 mb-10">
        {aboutFeatures.map((item, index) => (
          <div key={index} className="text-center">
            <item.icon size={48} className="text-customPrimary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-800 mb-2">
              {item.title}
            </h3>
            <p className="text-gray-600">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          Join Our Community
        </h2>
        <p className="text-gray-600 mb-4">
          Stay connected with us and be a part of our growing community. Follow
          us on social media and subscribe to our newsletter for the latest
          updates and offers.
        </p>
        <div className="flex justify-center space-x-4">
          {socialLinks.map((link, index) => (
            <a
              key={index}
              href={link.href}
              className="text-customPrimary hover:text-customPrimary-dark"
            >
              <link.icon size={32} />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
