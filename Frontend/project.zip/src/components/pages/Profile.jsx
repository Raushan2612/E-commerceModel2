import { useEffect, useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaPhone,
  FaHome,
  FaEdit,
  FaEye,
  FaHistory,
  FaUserTie,
  FaTimes,
} from "react-icons/fa";
import UserService from "../../service/UserService";
import ProfileOrderDetails from "../common/ProfileOrderDetails";
import AddressModal from "../common/AddressModal";

const Profile = () => {
  const [userInfo, setUserInfo] = useState(null);
  const [address, setAddress] = useState({
    street: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
  });
  const [error, setError] = useState(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);

  const fetchUserInfo = async () => {
    try {
      const response = await UserService.getLoggedInUserInfo();
      setUserInfo(response.user);
      console.log(response.user);
      
      setAddress(response.user.address);
    } catch (error) {
      setError(
        error.response?.data?.message ||
          error.message ||
          "Unable to fetch user info"
      );
    }
  };

  const handleAddressClick = () => {
    setIsEdit(!!userInfo.address);
    setIsAddressModalOpen(true);
  };

  const openOrderModal = (order) => {
    setSelectedOrder(order);
    setIsOrderModalOpen(true);
  };

  const closeOrderModal = () => {
    setIsOrderModalOpen(false);
    setSelectedOrder(null);
  };

  const closeAddressModal = () => {
    setIsAddressModalOpen(false);
  };

  useEffect(() => {
    fetchUserInfo();
  }, []);

  if (!userInfo) {
    return <div>Loading...</div>;
  }

  return (
    <>
      {error ? (
        <p
          className="error-message bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative"
          role="alert"
        >
          <span className="block sm:inline">{error}</span>
          <span className="absolute top-0 bottom-0 right-0 px-4 py-3">
            <FaTimes
              className="fill-current h-6 w-6 text-red-500"
              role="button"
            />
          </span>
        </p>
      ) : (
        <div className="flex flex-col items-center justify-center min-h-screen pt-20 shadow-lg">
          <h1 className="text-2xl font-extrabold text-center mb-2 md:mb-4 text-customPrimary">
            Hey, {userInfo.name}!
          </h1>
          <div className="max-w-4xl w-full bg-white shadow-lg rounded-lg p-8 space-y-8 m-4">
            {/* Profile Section */}
            <div>
              <h2 className="text-lg md:text-2xl font-bold mb-6 flex items-center text-customPrimary">
                <FaUserTie className="mr-2" /> Personal Details
              </h2>
              <div className="flex flex-col md:flex-row p-4 rounded-lg border-none">
                <div className="flex-1 mb-4 md:mb-0">
                  <div className="mb-6 flex items-center">
                    <FaUser className="text-gray-700 mr-3" />
                    <p className="text-gray-900 text-md">{userInfo.name}</p>
                  </div>
                  <div className="mb-3 flex items-center">
                    <FaPhone className="text-gray-700 mr-3" />
                    <p className="text-gray-900 text-md">
                      {userInfo.phoneNumber}
                    </p>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="mb-6 flex items-center">
                    <FaEnvelope className="text-gray-700 mr-4" />
                    <p className="text-gray-900 text-md">{userInfo.email}</p>
                  </div>
                  <div className="mb-3 flex items-center">
                    <FaHome className="text-gray-700 mr-3" size={18} />
                    {userInfo.address ? (
                      <p className="text-gray-900 text-md">
                        {userInfo.address.street +
                          ", " +
                          userInfo.address.city +
                          ", " +
                          userInfo.address.state +
                          ", " +
                          userInfo.address.country
                            .substring(0, 2)
                            .toUpperCase()}
                      </p>
                    ) : (
                      <p className="text-gray-900 text-md">
                        No Address information available
                      </p>
                    )}
                    <button
                      className="ml-4 bg-customPrimary text-white py-2 pl-[10px] pr-2 rounded-md hover:bg-gray-80 flex items-center"
                      onClick={handleAddressClick}
                    >
                      <FaEdit className="text-white" size={15} />
                    </button>
                  </div>
                </div>
              </div>
              <hr className="border-gray-300 my-6" />
            </div>

            {/* Order History Section */}
            <div>
              <h2 className="text-lg md:text-2xl font-bold mb-6 flex items-center text-customPrimary">
                <FaHistory className="mr-2" /> Order History
              </h2>
              {userInfo.orderList ? (<ul className="space-y-6">
                {userInfo.orderList.map((order) => (
                  <li
                    key={order.id}
                    className="flex justify-between items-center bg-gray-100 p-4 rounded-lg shadow-sm"
                  >
                    <div>
                      <p className="text-gray-900 font-semibold">
                        Order #{order.id} - {order.status}
                      </p>
                      <div className="flex items-center text-gray-600">
                        <p className="pr-5">
                          Total Products: {order.orderItemList.length}
                        </p>
                        <p>Total Price: ₹{order.totalPrice.toFixed(2)}</p>
                      </div>
                    </div>
                    <button
                      className="text-gray-700 hover:text-gray-900"
                      onClick={() => openOrderModal(order)}
                    >
                      <FaEye />
                    </button>
                  </li>
                ))}
              </ul>) : <p>Order is not placed yet</p>}
              
            </div>
          </div>
        </div>
      )}
      {selectedOrder && (
        <ProfileOrderDetails
          isOpen={isOrderModalOpen}
          closeModal={closeOrderModal}
          order={selectedOrder}
        />
      )}
      <AddressModal
        isOpen={isAddressModalOpen}
        closeModal={closeAddressModal}
        isEdit={isEdit}
        fetchUserInfo={fetchUserInfo}
        address={address}
        setAddress={setAddress}
      />
    </>
  );
};

export default Profile;
