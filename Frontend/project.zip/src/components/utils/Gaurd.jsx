import { Navigate, useLocation } from "react-router-dom";
import UtilService from "../../service/UtilService";

export const ProtectedRoute = ({ element: Component }) => {
  const location = useLocation();

  return UtilService.isAuthenticated() ? (
    Component
  ) : (
    <Navigate to="/login" replace state={{ from: location }} />
  );
};

export const AdminRoute = ({ element: Component }) => {
  const location = useLocation();

  return UtilService.isAdmin() ? (
    Component
  ) : (
    <Navigate to="/*" replace state={{ from: location }} />
  );
};
