import { useReducer, useEffect } from "react";
import { cartTypes } from "../../service/utils/Constants";
import CartContext from "./CartContext";

const initialState = {
  cart: JSON.parse(localStorage.getItem("cart")) || [],
};

const cartReducer = (state, action) => {
  switch (action.type) {
    case cartTypes.ADD: {
      // const existingItem = state.cart.find(
      //   (item) => item.id === action.payload.id
      // );

      let newCart;

      // if (existingItem) {
      //   newCart = state.cart.map((item) =>
      //     item.id === action.payload.id
      //       ? { ...item, quantity: item.quantity + 1 }
      //       : item
      //   );
      // } else {
      newCart = [...state.cart, { ...action.payload, quantity: 1 }];
      // }
      localStorage.setItem("cart", JSON.stringify(newCart));
      return { ...state, cart: newCart };
    }

    case cartTypes.REMOVE: {
      const newCart = state.cart.filter(
        (item) => item.id !== action.payload.id
      );
      localStorage.setItem("cart", JSON.stringify(newCart));
      return { ...state, cart: newCart };
    }

    case cartTypes.INCREMENT: {
      const newCart = state.cart.map((item) =>
        item.id === action.payload.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      localStorage.setItem("cart", JSON.stringify(newCart));
      return { ...state, cart: newCart };
    }

    case cartTypes.DECREMENT: {
      const newCart = state.cart.map((item) =>
        item.id === action.payload.id && item.quantity > 1
          ? { ...item, quantity: item.quantity - 1 }
          : item
      );
      localStorage.setItem("cart", JSON.stringify(newCart));
      return { ...state, cart: newCart };
    }

    case cartTypes.CLEAR: {
      localStorage.removeItem("cart");
      return { ...state, cart: [] };
    }
    default:
      return state;
  }
};

const CartProvider = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(state.cart));
  }, [state.cart]);

  return (
    <CartContext.Provider value={{ cart: state.cart, dispatch }}>
      {children}
    </CartContext.Provider>
  );
};

export default CartProvider;
