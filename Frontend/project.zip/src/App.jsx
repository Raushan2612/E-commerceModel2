import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Navbar from "./components/common/Navbar";
import Login from "./components/pages/Login";
import Registration from "./components/pages/Registration";
import Profile from "./components/pages/Profile";
import Home from "./components/pages/Home";
import ProductDetails from "./components/pages/ProductDetails";
import Cart from "./components/pages/Cart";
import AdminCategory from "./components/admin/AdminCategory";
import AdminProduct from "./components/admin/AdminProduct";
import AdminOrderDetails from "./components/admin/AdminOrderDetails";
import Admin from "./components/admin/Admin";
import Footer from "./components/common/Footer";
import AdminOrders from "./components/admin/AdminOrders";
import Shop from "./components/pages/Shop";
import About from "./components/pages/About";
import AdminUsers from "./components/admin/AdminUser";
import NotFound from "./components/common/NotFound";
import { AdminRoute, ProtectedRoute } from "./components/utils/Gaurd";
import { ToastContainer } from "react-toastify";
import CartProvider from "./components/context/CartProvider";

const App = () => {
  return (
    <BrowserRouter>
      <CartProvider>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/about" element={<About />} />
          <Route path="/product/:productId" element={<ProductDetails />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/login" element={<Login />} />

          <Route
            path="/profile"
            element={<ProtectedRoute element={<Profile />} />}
          />

          <Route path="/admin" element={<AdminRoute element={<Admin />} />} />
          <Route
            path="/admin/categories"
            element={<AdminRoute element={<AdminCategory />} />}
          />
          <Route
            path="/admin/products"
            element={<AdminRoute element={<AdminProduct />} />}
          />
          <Route
            path="/admin/orders"
            element={<AdminRoute element={<AdminOrders />} />}
          />
          <Route
            path="/admin/order-details/:itemId"
            element={<AdminRoute element={<AdminOrderDetails />} />}
          />
          <Route
            path="/admin/users"
            element={<AdminRoute element={<AdminUsers />} />}
          />

          <Route path="/*" element={<NotFound />} />
        </Routes>
        <ToastContainer />
        <Footer />
      </CartProvider>
    </BrowserRouter>
  );
};

export default App;
