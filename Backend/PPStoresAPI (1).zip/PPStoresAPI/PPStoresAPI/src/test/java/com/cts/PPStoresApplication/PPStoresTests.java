package com.cts.PPStoresApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.ppstores.PPStoresApplication;

@SpringBootTest(classes = PPStoresApplication.class)
class PPStoresTests {

	@Test
	void contextLoads() {
	}

}
