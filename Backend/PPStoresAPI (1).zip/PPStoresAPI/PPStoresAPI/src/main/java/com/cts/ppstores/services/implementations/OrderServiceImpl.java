package com.cts.ppstores.services.implementations;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.cts.ppstores.controllers.mappers.EntityDtoMapper;
import com.cts.ppstores.dtos.OrderDto;
import com.cts.ppstores.dtos.OrderItemDto;
import com.cts.ppstores.dtos.OrderItemRequest;
import com.cts.ppstores.dtos.OrderRequest;
import com.cts.ppstores.dtos.Response;
import com.cts.ppstores.dtos.UserDto;
import com.cts.ppstores.enums.OrderStatus;
import com.cts.ppstores.exceptions.NotFoundException;
import com.cts.ppstores.models.Order;
import com.cts.ppstores.models.OrderItem;
import com.cts.ppstores.models.Product;
import com.cts.ppstores.models.User;
import com.cts.ppstores.repositories.OrderItemRepo;
import com.cts.ppstores.repositories.OrderRepo;
import com.cts.ppstores.repositories.ProductRepo;
import com.cts.ppstores.services.interfaces.OrderService;
import com.cts.ppstores.services.interfaces.UserService;
import com.cts.ppstores.specifications.OrderItemSpecification;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepo orderRepo;
    private final OrderItemRepo orderItemRepo;
    private final ProductRepo productRepo;
    private final UserService userService;
    private final EntityDtoMapper entityDtoMapper;

    @Override
    public Response placeOrder(OrderRequest orderRequest) {

    	log.info("Placing order: {}", orderRequest);
    	
        User user = userService.getLoginUser();
        
        List<OrderItem> orderItemList = new ArrayList<>();
        for (OrderItemRequest orderItemRequest : orderRequest.getItems()) {
        	
            Product product = productRepo.findById(orderItemRequest.getProductId())
                    .orElseThrow(() -> new NotFoundException("Product Not Found"));

            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(product);
            orderItem.setQuantity(orderItemRequest.getQuantity());
            
            BigDecimal totalPriceWithoutTax = product.getPrice().multiply(BigDecimal.valueOf(orderItemRequest.getQuantity()));
            BigDecimal taxAmount = totalPriceWithoutTax.multiply(BigDecimal.valueOf(0.10));
            BigDecimal totalPriceWithTax = totalPriceWithoutTax.add(taxAmount);
            BigDecimal totalPriceWithOtherCharges = totalPriceWithTax.add(BigDecimal.valueOf(5));
            orderItem.setPrice(totalPriceWithOtherCharges);
//            orderItem.setPrice(product.getPrice());
            orderItem.setStatus(OrderStatus.PENDING);
            orderItem.setUser(user);

            orderItemList.add(orderItem);
        }

//        BigDecimal totalPrice;
//        if (orderRequest.getTotalPrice() != null && orderRequest.getTotalPrice().compareTo(BigDecimal.ZERO) > 0) {
//            totalPrice = orderRequest.getTotalPrice();
//        } else {
//            totalPrice = BigDecimal.ZERO;
//            for (OrderItem orderItem : orderItemList) {
//                totalPrice = totalPrice.add(orderItem.getPrice());
//            }
//        }
        
        BigDecimal totalPrice = BigDecimal.ZERO;
        for (OrderItem orderItem : orderItemList) {
        	totalPrice = totalPrice.add(orderItem.getPrice());
        }
        
        Order order = new Order();
        order.setOrderItemList(orderItemList);
        order.setTotalPrice(totalPrice);
        order.setUser(user);
        order.setStatus(OrderStatus.PENDING);

        for(OrderItem orderItem : orderItemList) {
        	orderItem.setOrder(order);
        }

        orderRepo.save(order);
        
        log.info("Order placed successfully: {}", order);

        return Response.builder()
                .status(200)
                .message("Order was successfully placed")
                .build();
    }

    @Override
    public Response updateOrderStatus(Long orderId, String status) {
    	
    	log.info("Updating order status for ID {}: {}", orderId, status);
    	
        Order order = orderRepo.findById(orderId)
                .orElseThrow(()-> new NotFoundException("Order not found"));

        order.setStatus(OrderStatus.valueOf(status.toUpperCase()));
        orderRepo.save(order);
        
        log.info("Order item updated successfully: {}", order);
        
        return Response.builder()
                .status(200)
                .message("Order status updated successfully")
                .build();
    }
    
    @Override
    public Response getOrderById(Long id) {
        Order order = orderRepo.findById(id).orElseThrow(() -> new NotFoundException("Order Details Not Found"));

            OrderDto orderDto = new OrderDto();
            orderDto.setId(order.getId());
            orderDto.setStatus(order.getStatus());
            orderDto.setTotalPrice(order.getTotalPrice());
            orderDto.setCreatedAt(order.getCreatedAt());
            
            UserDto userDto = entityDtoMapper.mapUserToDtoPlusAddressAndOrderHistory(order.getUser());
            userDto.setOrderItemList(null);
            orderDto.setUser(userDto);

            List<OrderItemDto> orderItemDtoList = new ArrayList<>();
            for (OrderItem orderItem : order.getOrderItemList()) {
                orderItemDtoList.add(entityDtoMapper.mapOrderItemToDtoPlusProduct(orderItem));
            }
            orderDto.setOrderItemList(orderItemDtoList);

            return Response.builder().status(200).order(orderDto).build();
        }
    
    @Override
    public Response getAllOrdersByUser() {
        User user = userService.getLoginUser();
        List<Order> orders = orderRepo.findByUser(user);
        List<OrderDto> orderDtoList = new ArrayList<>();

        for (Order order : orders) {
            OrderDto orderDto = new OrderDto();
            orderDto.setId(order.getId());
            orderDto.setStatus(order.getStatus());
            orderDto.setTotalPrice(order.getTotalPrice());
            orderDto.setCreatedAt(order.getCreatedAt());

            List<OrderItemDto> orderItemDtoList = new ArrayList<>();
            for (OrderItem orderItem : order.getOrderItemList()) {
                orderItemDtoList.add(entityDtoMapper.mapOrderItemToDtoPlusProduct(orderItem));
            }
            orderDto.setOrderItemList(orderItemDtoList);

            orderDtoList.add(orderDto);
        }
        
        return Response.builder().status(200).orderList(orderDtoList).build();
    }
    
    @Override
    public Response getAllOrders() {
        List<Order> orders = orderRepo.findAll();
        List<OrderDto> orderDtoList = new ArrayList<>();
        
        for (Order order : orders) {
            OrderDto orderDto = new OrderDto();
            orderDto.setId(order.getId());
            orderDto.setStatus(order.getStatus());
            orderDto.setTotalPrice(order.getTotalPrice());
            orderDto.setCreatedAt(order.getCreatedAt());
            
            UserDto userDto = entityDtoMapper.mapUserToDtoBasic(order.getUser());
            orderDto.setUser(userDto);

            List<OrderItemDto> orderItemDtoList = new ArrayList<>();
            for (OrderItem orderItem : order.getOrderItemList()) {
                orderItemDtoList.add(entityDtoMapper.mapOrderItemToDtoBasic(orderItem));
            }
            orderDto.setOrderItemList(orderItemDtoList);

            orderDtoList.add(orderDto);
        }
        
        return Response.builder().status(200).orderList(orderDtoList).build();
    }
    
    @Override
    public Response filterOrderItems(OrderStatus status, LocalDateTime startDate, LocalDateTime endDate, Long itemId, Pageable pageable) {
        Specification<OrderItem> spec = Specification.where(OrderItemSpecification.hasStatus(status))
                .and(OrderItemSpecification.createdBetween(startDate, endDate))
                .and(OrderItemSpecification.hasItemId(itemId));
        Page<OrderItem> orderItemPage = orderItemRepo.findAll(spec, pageable);
        if (orderItemPage.isEmpty()){
            throw new NotFoundException("No Order Found");
        }
        List<OrderItemDto> orderItemDtos = new ArrayList<>();
        for (OrderItem orderItem : orderItemPage.getContent()) {
            OrderItemDto dto = entityDtoMapper.mapOrderItemToDtoPlusProductAndUser(orderItem);
            orderItemDtos.add(dto);
        }
        return Response.builder()
                .status(200)
                .orderItemList(orderItemDtos)
                .build();
    }
}