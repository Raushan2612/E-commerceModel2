package com.cts.ppstores.controllers;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.cts.ppstores.dtos.OrderRequest;
import com.cts.ppstores.dtos.Response;
import com.cts.ppstores.enums.OrderStatus;
import com.cts.ppstores.services.interfaces.OrderService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public ResponseEntity<Response> placeOrder(@RequestBody @Valid OrderRequest orderRequest){
        Response response = orderService.placeOrder(orderRequest);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/updateOrderStatus/{orderItemId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Response> updateOrderStatus(@PathVariable Long orderItemId,  @RequestParam String status){
        Response response = orderService.updateOrderStatus(orderItemId, status);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/getOrderById/{id}")
    public ResponseEntity<Response> getOrderById(@PathVariable Long id){
        Response response = orderService.getOrderById(id);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/getAllOrdersByUser")
    public ResponseEntity<Response> getAllOrdersByUser(){
        Response response = orderService.getAllOrdersByUser();
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/getAllOrders")
    public ResponseEntity<Response> getAllOrders(){
        Response response = orderService.getAllOrders();
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/filter")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Response> filterOrderItems(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)LocalDateTime startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)LocalDateTime endDate,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Long itemId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "1000") int size
            ){
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "id"));
        OrderStatus orderStatus = status != null ? OrderStatus.valueOf(status.toUpperCase()) : null;
        return ResponseEntity.ok(orderService.filterOrderItems(orderStatus, startDate, endDate, itemId, pageable));
    }
}