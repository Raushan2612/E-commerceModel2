package com.cts.ppstores.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.ppstores.models.Order;
import com.cts.ppstores.models.User;

public interface OrderRepo extends JpaRepository<Order, Long> {
	List<Order> findByUser(User user);
}