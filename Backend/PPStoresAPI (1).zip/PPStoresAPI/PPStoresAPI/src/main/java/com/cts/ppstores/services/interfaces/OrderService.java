package com.cts.ppstores.services.interfaces;

import java.time.LocalDateTime;

import org.springframework.data.domain.Pageable;

import com.cts.ppstores.dtos.OrderRequest;
import com.cts.ppstores.dtos.Response;
import com.cts.ppstores.enums.OrderStatus;

public interface OrderService {
    Response placeOrder(OrderRequest orderRequest);
    Response updateOrderStatus(Long orderId, String status);
    Response filterOrderItems(OrderStatus status, LocalDateTime startDate, LocalDateTime endDate, Long itemId, Pageable pageable);
    Response getOrderById(Long id);
    Response getAllOrdersByUser();
    Response getAllOrders();
}